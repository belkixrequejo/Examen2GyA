# Affliction
A content focused responsive theme for [Ghost](https://github.com/tryghost/ghost/) by [Petro Popelyshko](https://antistartup.io).

## Features

* Responsive layout
* Infinite scroll

## Previews


<table>
<tr>
<img src="https://media.giphy.com/media/j6ZkUYpYWtJPsRLTaD/giphy.gif" />
</td>
<td valign="top">
<img src="https://media.giphy.com/media/lp6yyttODJfQYmVJKk/giphy.gif" />
</td>
</tr>
</table>

## License

Copyright (C) 2019 Petro Popelyshko - Released under the MIT License.
